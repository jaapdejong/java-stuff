package com.nedap.retail.examples;

public class SharedIntExample {

    private static int counter = 0;

    private static void runThread() {
        for (int i = 0; i < 1000000; i++) {
            counter++;
        }
    }

    public static void main(String[] args) throws InterruptedException {
        final Thread thread = new Thread(SharedIntExample::runThread);

        thread.start();

        for (int i = 0; i < 1000000; i++) {
            counter++;
        }

        thread.join();

        System.out.printf("Counter = %d%n", counter);
    }
}
