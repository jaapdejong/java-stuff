package com.nedap.retail.examples;

public class DeadLockExample {

    public class SomeClass {
        public synchronized void doSomething() {
            System.out.println("doSomething()");
        }
    }

    private final SomeClass object1 = new SomeClass();

    public synchronized void myMethod1() {
        someFunction();
        object1.doSomething();
    }

    public void myMethod2() {
        synchronized (object1) {
            myMethod1();
        }
    }

    private void someFunction() {
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            // ignore
        }
    }

    public static void main(String[] args) throws Exception {
        final DeadLockExample example = new DeadLockExample();

        final Thread t1 = new Thread(example::myMethod1);
        final Thread t2 = new Thread(example::myMethod2);
        t1.start();
        t2.start();

        t1.join();
        t2.join();
    }
}
