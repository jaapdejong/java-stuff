package com.nedap.retail.examples;

public class PollingIntExample {

    private static int a = 0;

    public static void main(String[] args) throws InterruptedException {
        final Thread t1 = new Thread(() -> {
            while (a == 0) {
            }

            System.out.println("Loop done: " + a);
        });

        t1.start();

        Thread.sleep(1000);

        System.out.println("Set a = 10");
        a = 10;

        t1.join();
    }
}
