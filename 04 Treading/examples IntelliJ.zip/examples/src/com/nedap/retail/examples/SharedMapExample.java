package com.nedap.retail.examples;

import java.util.HashMap;
import java.util.Map;

public class SharedMapExample {

    private static Map<Integer, Integer> map = new HashMap<>();

    private static void runThread() {
        for (int i = 0; i < 100; i++) {
            int total = 0;
            for (final Map.Entry<Integer, Integer> e : map.entrySet()) {
                total += e.getValue();
            }
            System.out.printf("Total = %d%n", total);
        }
    }

    public static void main(String[] args) throws InterruptedException {
        final Thread thread = new Thread(SharedMapExample::runThread);

        thread.start();

        for (int i = 0; i < 2000; i++) {
            map.put(i, i);
        }

        thread.join();
    }
}
